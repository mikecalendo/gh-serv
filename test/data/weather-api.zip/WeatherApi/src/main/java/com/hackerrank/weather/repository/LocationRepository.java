package com.hackerrank.weather.repository;

public interface LocationRepository {
}
