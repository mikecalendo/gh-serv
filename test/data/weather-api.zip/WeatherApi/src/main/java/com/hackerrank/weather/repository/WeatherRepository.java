package com.hackerrank.weather.repository;

public interface WeatherRepository {
}
