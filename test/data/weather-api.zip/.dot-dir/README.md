Text File under Dot Dir
